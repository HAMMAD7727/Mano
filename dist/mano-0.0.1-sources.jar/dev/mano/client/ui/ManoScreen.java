package dev.mano.client.ui;

import dev.mano.Mano;
import dev.mano.client.ManoRuntime;
import dev.mano.client.destruct.SelfDestruct;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Top navbar + one content panel. No modules — placeholders only.
 */
public final class ManoScreen extends class_437 {
	private enum Tab {
		MODULE("Module"),
		FRIENDS("Friends"),
		CONFIG("Config"),
		DESTRUCT("Self destruct");

		final String label;

		Tab(String label) {
			this.label = label;
		}
	}

	private static final int BAR_H = 40;
	private static final int PANEL_H = 168;
	private static final int ACCENT = 0xFF6EA8FF;
	private static final int TEXT = 0xFFE8ECF4;
	private static final int MUTED = 0xFF8B93A7;
	private static final int DANGER = 0xFFFF6B81;
	private static final int BAR_BG = 0xF20B0D12;
	private static final int PANEL_BG = 0xE612151E;
	private static final int HAIRLINE = 0x22FFFFFF;

	private Tab tab = Tab.MODULE;
	private float open = 0f;
	private boolean closing;
	private int confirmClicks;
	private long confirmUntil;

	public ManoScreen() {
		super(class_2561.method_43470(Mano.NAME));
	}

	public void beginClose() {
		closing = true;
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	protected void method_25426() {
		open = 0f;
		closing = false;
		confirmClicks = 0;
	}

	@Override
	public void method_25393() {
		if (!ManoRuntime.isAlive()) {
			this.field_22787.method_1507(null);
			return;
		}

		float speed = 0.18f;
		if (closing) {
			open = Math.max(0f, open - speed);
			if (open <= 0.001f) {
				this.field_22787.method_1507(null);
			}
		} else {
			open = Math.min(1f, open + speed);
		}

		if (confirmClicks > 0 && System.currentTimeMillis() > confirmUntil) {
			confirmClicks = 0;
		}
	}

	@Override
	public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
		// World stays visible under the chrome.
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		super.method_25394(context, mouseX, mouseY, delta);
		if (this.field_22787 == null) {
			return;
		}

		float t = easeOutCubic(open);
		int slide = Math.round((1f - t) * -(BAR_H + PANEL_H));

		int barTop = slide;
		int barBottom = slide + BAR_H;
		int panelTop = barBottom;
		int panelBottom = panelTop + PANEL_H;

		context.method_25294(0, barTop, this.field_22789, barBottom, BAR_BG);
		context.method_25294(0, barBottom - 1, this.field_22789, barBottom, ACCENT);
		context.method_25294(0, panelTop, this.field_22789, panelBottom, PANEL_BG);
		context.method_25294(0, panelBottom, this.field_22789, panelBottom + 1, HAIRLINE);

		int titleX = 18;
		int titleY = barTop + 14;
		context.method_51433(this.field_22793, Mano.NAME, titleX, titleY, TEXT, false);
		int nameW = this.field_22793.method_1727(Mano.NAME);
		context.method_51433(this.field_22793, Mano.VERSION, titleX + nameW + 8, titleY, MUTED, false);

		int tabStart = Math.max(160, this.field_22789 / 3);
		int tabW = Math.min(110, Math.max(72, (this.field_22789 - tabStart - 16) / Tab.values().length));
		int i = 0;
		for (Tab candidate : Tab.values()) {
			int x = tabStart + i * tabW;
			boolean hover = mouseX >= x && mouseX < x + tabW && mouseY >= barTop && mouseY < barBottom;
			boolean active = candidate == tab;
			int color = active ? TEXT : (hover ? 0xFFD0D6E4 : MUTED);
			int labelW = this.field_22793.method_1727(candidate.label);
			int lx = x + (tabW - labelW) / 2;
			context.method_51433(this.field_22793, candidate.label, lx, titleY, color, false);
			if (active) {
				int ux1 = x + 12;
				int ux2 = x + tabW - 12;
				context.method_25294(ux1, barBottom - 3, ux2, barBottom - 1, candidate == Tab.DESTRUCT ? DANGER : ACCENT);
			}
			i++;
		}

		renderPanel(context, panelTop, mouseX, mouseY);
	}

	private void renderPanel(class_332 context, int panelTop, int mouseX, int mouseY) {
		int x = 22;
		int y = panelTop + 22;
		switch (tab) {
			case MODULE -> {
				heading(context, x, y, "Modules");
				body(context, x, y + 18, "Nothing here in 0.01 V. This tab is a placeholder.");
			}
			case FRIENDS -> {
				heading(context, x, y, "Friends");
				body(context, x, y + 18, "Friend list comes later. No entries yet.");
			}
			case CONFIG -> {
				heading(context, x, y, "Config");
				body(context, x, y + 18, "Menu  ·  Right Shift");
				body(context, x, y + 34, "Silent unload  ·  hold Right Ctrl + Backspace");
				body(context, x, y + 50, "No settings to save in this build.");
			}
			case DESTRUCT -> {
				heading(context, x, y, "Self destruct");
				body(context, x, y + 18, "Unloads Mano from this session. The jar on disk stays.");
				body(context, x, y + 34, "Restart Minecraft to load it again.");

				String label = confirmClicks == 0 ? "Self destruct" : "Click again to confirm";
				int bw = 168;
				int bh = 28;
				int bx = x;
				int by = y + 64;
				boolean hover = mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh;
				int fill = hover ? 0xFFE2556A : 0xFFC43D54;
				context.method_25294(bx, by, bx + bw, by + bh, fill);
				context.method_25294(bx, by, bx + bw, by + 1, 0x33FFFFFF);
				int lw = this.field_22793.method_1727(label);
				context.method_51433(this.field_22793, label, bx + (bw - lw) / 2, by + 10, 0xFFFFFFFF, false);
			}
		}

		String hint = "esc  close     rshift  toggle";
		context.method_51433(this.field_22793, hint.toUpperCase(Locale.ROOT), x, panelTop + PANEL_H - 22, 0xFF4E5568, false);
	}

	private void heading(class_332 context, int x, int y, String s) {
		context.method_51433(this.field_22793, s, x, y, TEXT, false);
	}

	private void body(class_332 context, int x, int y, String s) {
		context.method_51433(this.field_22793, s, x, y, MUTED, false);
	}

	@Override
	public boolean method_25402(class_11909 click, boolean doubled) {
		if (!ManoRuntime.isAlive()) {
			return false;
		}
		double mouseX = click.comp_4798();
		double mouseY = click.comp_4799();
		int button = click.method_74245();
		if (button != 0) {
			return super.method_25402(click, doubled);
		}

		float t = easeOutCubic(open);
		int slide = Math.round((1f - t) * -(BAR_H + PANEL_H));
		int barTop = slide;
		int barBottom = slide + BAR_H;
		int panelTop = barBottom;

		int tabStart = Math.max(160, this.field_22789 / 3);
		int tabW = Math.min(110, Math.max(72, (this.field_22789 - tabStart - 16) / Tab.values().length));
		int i = 0;
		for (Tab candidate : Tab.values()) {
			int x = tabStart + i * tabW;
			if (mouseX >= x && mouseX < x + tabW && mouseY >= barTop && mouseY < barBottom) {
				tab = candidate;
				confirmClicks = 0;
				return true;
			}
			i++;
		}

		if (tab == Tab.DESTRUCT) {
			int bx = 22;
			int by = panelTop + 22 + 64;
			int bw = 168;
			int bh = 28;
			if (mouseX >= bx && mouseX <= bx + bw && mouseY >= by && mouseY <= by + bh) {
				onDestructClicked();
				return true;
			}
		}

		return super.method_25402(click, doubled);
	}

	private void onDestructClicked() {
		long now = System.currentTimeMillis();
		if (confirmClicks == 0 || now > confirmUntil) {
			confirmClicks = 1;
			confirmUntil = now + 2500L;
			return;
		}
		SelfDestruct.execute();
	}

	@Override
	public boolean method_25404(class_11908 input) {
		if (input.comp_4795() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
			beginClose();
			return true;
		}
		if (input.comp_4795() == GLFW.GLFW_KEY_ESCAPE) {
			beginClose();
			return true;
		}
		return super.method_25404(input);
	}

	@Override
	public void method_25419() {
		beginClose();
	}

	private static float easeOutCubic(float x) {
		float inv = 1f - x;
		return 1f - inv * inv * inv;
	}
}
