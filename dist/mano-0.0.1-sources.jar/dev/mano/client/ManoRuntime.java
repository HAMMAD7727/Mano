package dev.mano.client;

import net.minecraft.class_310;

/**
 * Session-level switch. Once flipped, every Mano hook no-ops until the game restarts.
 */
public final class ManoRuntime {
	private static volatile boolean alive = true;

	private ManoRuntime() {
	}

	public static boolean isAlive() {
		return alive;
	}

	public static void markDestroyed() {
		alive = false;
		class_310 client = class_310.method_1551();
		if (client != null && client.field_1755 instanceof dev.mano.client.ui.ManoScreen) {
			client.execute(() -> {
				if (client.field_1755 instanceof dev.mano.client.ui.ManoScreen) {
					client.method_1507(null);
				}
			});
		}
	}
}
