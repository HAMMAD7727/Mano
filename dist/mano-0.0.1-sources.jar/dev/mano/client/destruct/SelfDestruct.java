package dev.mano.client.destruct;

import dev.mano.Mano;
import dev.mano.client.ManoClient;
import dev.mano.client.ManoRuntime;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;

/**
 * Silent wipe of the in-memory client. Does not delete the jar on disk.
 *
 * Gesture: hold Right Ctrl + Backspace for HOLD_MS (ignored while typing in chat).
 */
public final class SelfDestruct {
	public static final long HOLD_MS = 1200L;

	private static long holdStartedAt = -1L;

	private SelfDestruct() {
	}

	public static void tick(class_310 client) {
		if (!ManoRuntime.isAlive() || client.method_22683() == null) {
			return;
		}
		if (client.field_1755 instanceof class_408) {
			holdStartedAt = -1L;
			return;
		}

		boolean combo = class_3675.method_15987(client.method_22683(), GLFW.GLFW_KEY_RIGHT_CONTROL)
			&& class_3675.method_15987(client.method_22683(), GLFW.GLFW_KEY_BACKSPACE);

		if (!combo) {
			holdStartedAt = -1L;
			return;
		}

		long now = System.currentTimeMillis();
		if (holdStartedAt < 0L) {
			holdStartedAt = now;
			return;
		}
		if (now - holdStartedAt >= HOLD_MS) {
			execute();
		}
	}

	public static void execute() {
		if (!ManoRuntime.isAlive()) {
			return;
		}
		holdStartedAt = -1L;
		ManoRuntime.markDestroyed();
		ManoClient.LOGGER.info("{} {} unloaded", Mano.NAME, Mano.VERSION);
	}
}
