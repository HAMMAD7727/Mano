package dev.mano.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class ManoKeys {
	public static final class_304 OPEN = KeyBindingHelper.registerKeyBinding(new class_304(
		"key.mano.open",
		class_3675.class_307.field_1668,
		GLFW.GLFW_KEY_LEFT_SHIFT,
		class_304.class_11900.field_62556
	));

	private ManoKeys() {
	}

	public static void register() {
		// static init registers the bind
	}
}
